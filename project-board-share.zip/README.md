# Project Board Share Package

This folder is the share-ready version of your project board app.

## Best hosting option

Use GitHub Pages, Netlify, or Vercel. Since this app is one HTML file and everyone keeps their own separate board in their browser, GitHub Pages is the simplest fit.

Your friends will use one link, like:

```text
https://your-github-name.github.io/project-board/
```

When you update the app and publish again, they keep using the same link. They may need to refresh the page.

## Files

- `index.html` - the hosted app file.
- `.nojekyll` - keeps GitHub Pages from doing extra processing.
- `sync-from-bookmark.ps1` - copies your latest bookmarked app into this folder.

## Updating This Folder

After Codex edits your main bookmarked file at:

```text
C:\Users\pablo\OneDrive\Documents\project-board.html
```

Run this from this folder:

```powershell
.\sync-from-bookmark.ps1
```

Then upload or push the updated `index.html` to your host.

## GitHub Pages Setup

1. Create a GitHub repository named `project-board`.
2. Upload these files to the repository root.
3. In GitHub, go to `Settings` > `Pages`.
4. Set the source to deploy from the main branch root.
5. Share the Pages URL with your friends.

Each friend gets their own saved board because the app stores data in their browser's local storage.
